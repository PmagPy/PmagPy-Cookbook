# To convert this file to MagIC use the followig command line:
generic_magic.py -f generic_demag.txt -F generic_demag.magic -usr rshaar -exp Demag -samp 1 1 -site 2 - -loc Agros
