#!/usr/bin/env python
mylist=[42,`spam',`ocelot']
Indices=range(0,len(mylist),1)
for i in Indices:
   print mylist[i]
print 'All done' 
