#!/usr/bin/env python
# simple Python test program (printmess.py)
print 'test message'
