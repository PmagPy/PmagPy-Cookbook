#!/usr/bin/env python
a=1
while a < 10:
    print a
    a+=1
print "I'm done counting!"
