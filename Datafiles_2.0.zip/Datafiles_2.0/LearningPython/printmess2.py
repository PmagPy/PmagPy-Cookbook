#! /usr/bin/env python
# simple Python test program 2 (printmess2.py)
print "The pump don't work 'cuz the vandals took the handles"
print 'She said "I know what it\'s like to be dead"'
