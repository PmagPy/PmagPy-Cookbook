#!/usr/bin/env python
if (2+2)==4: # note the use of '==' and parentheses in comparison statement
   print "I can put two and two together!"
