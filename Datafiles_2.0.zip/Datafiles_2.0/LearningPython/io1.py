#!/usr/bin/env python
X=[]
X=[] # make a list to put the data in
ans=float(raw_input("Input numeric value for X:  ")) 
X.append(ans) # append the value to X
print X[-1]
