#!/usr/bin/env python
mylist=[42,`spam',`ocelot']
for item in mylist: # note absence of range statement
    print item
print 'All done' 
