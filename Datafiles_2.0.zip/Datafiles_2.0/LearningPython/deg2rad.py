#!/usr/bin/env python
def deg2rad(degrees):  
    """
    converts degrees to radians
    """
    return degrees*3.141592653589793/180.
print '42 degrees in radians is: ',deg2rad(42.)
    
